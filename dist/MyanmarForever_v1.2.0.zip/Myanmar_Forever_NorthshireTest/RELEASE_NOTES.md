# MyanmarForever 1.2.0

This update adds 22 quests across the early Alliance and Horde leveling routes. It also adds the progress reply for The State of the Mines, verified against a live capture.

- **Westfall and the Deadmines:** The Moonbrook alchemy pair, two Harvester follow-ups, Oh Brother…, Collecting Memories and Underground Assault.
- **Dun Morogh and Loch Modan:** The Quarry's Smith, Excavation Tools and Twisting the Knife.
- **Teldrassil:** Darkness in the Glade and The Oracle Tree.
- **Durotar:** A Simmering Storm and Stormy Potential.
- **Mulgore and Thunder Bluff:** The three Stalk With The Earthmother steps.
- **Silverpine Forest:** Prove Your Worth and the four Arugal's Folly steps.

Skyborne characters follow the shared mainland quests available to their faction. Native proofreading and live eligibility checks are pending.

Exit WoW before replacing the complete `Myanmar_Forever_NorthshireTest` folder in `Interface/AddOns`. Keep your SavedVariables to carry over settings and captures.
