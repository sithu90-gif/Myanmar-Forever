# MyanmarForever 1.2.7

The morning update adds 50 quest records and 162 translated fields. Total coverage: 1,286 quest IDs and 5,932 translated fields.

- 21 Alliance Priest level-10 records: Desperate Prayer, Human Divine Grace and Gnome Confounding Flash training alternatives.
- 24 Priest racial-training records through level 20: Undead Touch of Weakness/Dark Sacrifice, Troll Shadowguard, Night Elf Elune's Grace, Human Arcane Feedback, Gnome Contingency Plan and the Dwarf training steps.
- Five connected Alliance Call of Fire steps at quest levels 10-14, through Dun Morogh and Loch Modan.

Every ID and available dialogue field was counter-checked against fresh official UA_Forever 1.0.0, current English and installed QuestieDB 1.0.12. UA is unchanged since the previous release. Current English calls Dwarf IDs 5641/5645/5647 Chastise while installed/UA metadata calls them A Lack of Fear; the exact alternate title is documented per ID. Live title/spell applicability remains for player verification. UA still calls IDs 5644/5646/5679 Devouring Plague; current English reward and installed metadata identify Dark Sacrifice. The old UA label is documented separately and is not accepted as a runtime title alias.

Conflicting trainer/city referrals, unresolved gender variants and a suspicious literal-name completion remain disabled with evidence. Genuine absent states remain explicit, including completion-only lessons. Supported secondary English is used only with matching identity and field-specific evidence. The five Fire-chain steps retain their distinct recipients, reagents, elemental battle, brazier and return journey.

All available English fields passed through DeepL MY before editorial review, followed by separate source-aware and independent assisted review. Native Myanmar proofreading, pronunciation approval and current in-game/controller verification remain pending. This is per-ID/state coverage, not complete coverage for every race or level.

Fully exit WoW, preserve SavedVariables and replace the complete Myanmar_Forever_NorthshireTest folder in Interface/AddOns. Keep the rebuilt font and catalog together. Automatic local missing-dialogue capture remains enabled; reload or logout saves captures. CurseForge and social publishing require a separate request for this release.
