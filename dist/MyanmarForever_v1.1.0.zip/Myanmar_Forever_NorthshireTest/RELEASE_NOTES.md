# MyanmarForever 1.1.0

- Adds **94 quests and 440 translated fields**, for **946 quest IDs / 4,423 fields** overall. The Undead packs now contain 118 quest records across roughly levels 1–13.
- Extends the Undead route beyond Deathknell into Brill and Tirisfal Glades, including the Agamand Mills, Scarlet Crusade, plague and local follow-up chains.
- Includes Forever-specific Tirisfal quests, supported early class routes and local beginner Camping/profession introductions. Level-13 local finales and immediate capital/delivery handoffs are included; the Silverpine questing zone remains a later update.
- Continues the approved Undead translation style. Recognizable English names retain Myanmar pronunciation; quantities, directions and player placeholders follow the English source.
- Preserves all version 1.0.0 translations and automatic local quest capture. Use `/reload` or log out after opening NPC quest dialogue to save captures.
- Rebuilds the bundled font and quest catalog together as version **1.1.0**, without a beta or candidate suffix.

Fully exit WoW and replace the complete `Myanmar_Forever_NorthshireTest` folder in `Interface/AddOns`. Keep that folder name and your existing SavedVariables. Commands: `/mmforever` and `/mmnorth`.

Coverage follows reviewed English evidence. Unavailable or conflicting source states retain the original-language fallback; database listings do not establish current live eligibility. Full native Myanmar proofreading and current live-client/controller verification remain pending.

Source, field-level evidence and validation: https://github.com/sithu90-gif/Myanmar-Forever
