# MyanmarForever 1.2.13

Adds 50 quest records / 187 enabled translated fields. Total: 1,536 quest IDs / 7,018 enabled fields.

- Sixteen Alliance records: all captured Deadmines/Stormwind city gaps, the connected Unsent Letter -> Stockade -> castle-infiltration chain through An Audience with the King, the captured wool donation and Retrieval for Mauren.
- Eighteen research-library records: sixteen distinct books and the Friend of the Library / Mage Research Access steps. Current per-ID faction/class restrictions apply.
- Sixteen route records: the Silverpine pendant/tomb, alternative Ashenvale Hunt referrals, Warsong updates linked to existing 6543, Zoram/Splintertree quests and the Alliance Stonetalon handoff.

All nine captured missing quest IDs and thirteen saved missing dialogue states are included. Saved captures establish prior gaps; this is not a current live playtest. Quest-level 60 on the min-level-12 wool donation does not establish level-60 route coverage or repeatability.

Official UA_Forever 1.0.4 pinned at e759b41bc4948e65b35fcf9a3fd9ae6642d7e5e1 with exact package/catalog hashes. Existing 398 title capitalization now matches our already reviewed label; all five English fields remain unchanged after whitespace normalization. All 50 new IDs counter-checked. Two research-book title discrepancies use current English and recorded source dispositions, without invalid runtime aliases.

Current Charred Vale objective plus four target rows require SIX EACH of four Bloodfury types; older UA/installed metadata says seven. Translation follows the current primary six with the conflict and live verification status documented. The Stockade chain preserves the conversation-before-kill/guards-return order and absent-king/representative handoff. Genuine source absences remain null, including book offer/objective and UA-only progress replies.

All 188 available fields, including held proposals, have actual DeepL MY provenance, editorial correction and separate 5-10-quest source-aware bilingual review followed by fresh independent review. New held fields: 1. Their reasons are in the review report; original English fallback and missing-state capture remain enabled.

Native Myanmar proofreading, new pronunciation approval and current live/controller testing remain pending. Exit WoW fully, preserve SavedVariables, then replace the complete Myanmar_Forever_NorthshireTest folder in Interface/AddOns, keeping rebuilt font/catalog together.
