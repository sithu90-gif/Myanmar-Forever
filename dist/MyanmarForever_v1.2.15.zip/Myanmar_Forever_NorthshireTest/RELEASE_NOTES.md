# MyanmarForever 1.2.15

Adds 50 quest records / 233 enabled translated fields. Total: 1,636 quest IDs / 7,477 enabled fields.

- 20 Stonetalon records: the Alliance Gaxim/Lomac/Mauren route, two Covert Ops branches and Kaela/Tyrande updates, Gerenzo/Piznik ore stages, Jin'Zil's forest materials, shredders and the supply run. Per-ID Alliance/Horde/neutral restrictions apply.
- 15 Ruins of Lordaeron records: New Plague, investigation and limb collection, five distinct Unending Torment stages, opposite-faction Crest turn-ins, insignias, letter deliveries and Rath'mael.
- 15 Darkshore/Ashenvale records: Althalaxx continuations and escort branch, the prospector collection, Volcor's force escape, and eight distinct Raene's Cleansing stages.

Also corrects neutral rod wording in two existing Raene detail fields (991 and1024), under exact prior-hash guards. No other historical text is changed.

Official UA_Forever 1.1.0 pinned at f34f1227d5837a05e18f1d5554d8aff6544b2515 with exact package/catalog hashes. Compared with1.0.5, only quest5147 English title changed to WANTED: Arnak Grimtotem; it is outside the composed Myanmar catalog. All 50 new IDs and the composed catalog were counter-checked against it, current English and refreshed installed metadata.

All 234 available new source fields, including held proposals, have actual DeepL MY provenance, editorial review in seven connected 5–10 quest groups and separate independent assisted review. New held fields: 1. Genuine source absences stay null; uncertain fields preserve the original English fallback. The review report documents their reasons.

This extends connected early routes; it does not establish complete coverage of every race or level. All 300 previously saved states across 128 quest IDs were covered before selection. Native Myanmar proofreading, new pronunciation approval and current live/controller testing remain pending.

Exit WoW fully, preserve SavedVariables, then replace the complete Myanmar_Forever_NorthshireTest folder in Interface/AddOns, keeping rebuilt font/catalog together.
