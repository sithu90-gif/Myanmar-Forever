# MyanmarForever 1.2.10

This afternoon update adds 50 quest records and 224 translated fields. Total: 1,386 quest IDs and 6,364 enabled fields.

- Hunter 14: remaining level-10 referrals for the Yaw Sharpmane, Thotar, Dazalar and Grif Wildheart routes, including city referral alternatives. These are separate same-title IDs leading to already translated training chains.
- Alliance capital/early routes 17: the Sisterhood/Temple/Sathrah sequence and Darnassus handoffs, Stormwind compass/delivery/library quests, Ironforge referrals and three Old Ironforge objectives.
- Horde burned-note counterpart 1: current quest 79007, "... and that note you found", preserves the charred-note and twin-land mystery without adding a destination. Current English, UA and installed metadata identify it as Horde. The same-title Alliance quest 79008 was already translated; the earlier screenshot title cannot establish which ID was displayed. No existing 79008 field was changed.
- Horde capital/early routes 18: all five Hidden Enemies steps, five connected Ragefire Chasm quests, five Orgrimmar side quests and three Thunder Bluff leather/ceremony quests. Required levels and restrictions remain per ID.

The new quests have installed quest levels 8-22, with Hunter referrals at 10. These selected records do not establish complete all-race/all-level coverage or current live eligibility. Shared IDs count once. Same-title steps retain their distinct recipients, items, stages and current player-marker case.

Official UA_Forever 1.0.1 was refreshed for this batch: exact commit ab388ca8df990310d96320c88689831587f76e33, package and catalog SHA-256 recorded. It is unchanged from the morning pin. All planned IDs are present; current English controls meaning. Three older obsolete upstream spell labels stay documented without invalid runtime aliases. Every prior reviewed field and the guarded 5639 hold are preserved.

All available new English fields and held proposals have actual DeepL MY request/response/index/hash evidence, editorial correction, separate 5-10-quest bilingual reviews and independent source-aware review. Maintained local pronunciation terms were used; cloud glossaries still require DeepL Pro. 1 new source/runtime fields are held rather than guessed. Native Myanmar proofreading, new pronunciation approval and current in-game/controller verification remain pending.

Fully exit WoW, preserve SavedVariables and replace the complete Myanmar_Forever_NorthshireTest folder in Interface/AddOns. Keep rebuilt font and catalog together. Automatic local missing-state capture remains enabled; reload or logout saves captures. No CurseForge or social publishing is included.
