# MyanmarForever 1.2.17

Adds 50 quest records / 235 enabled translated fields. Total: 1,736 quest IDs / 7,953 enabled fields.

- 20 regional records: the Orc Mage Glyphic Parchment referral; Barrens hunting/cooking/encroachment and Runed Scroll routes; Mirkweed pigments; Never Coming Back/Void Path, allthree Sacred Flame stages and Melor/Steelsnap; Baron Marinous, Culling the Threat, Fallen Sky Lake and the final Althalaxx pair. Questlevels reach31 despite early required minima.
- 15 Paladin records: alternative level12 Tome of Divinity referral, the complete12-step Silverpine Moonsilver Blade chain and distinct Alliance/Horde Kor Gem destinations. Current primary restricts the Moonsilver chain and95042 to Undead Paladins;3681Human,1442Human/Dwarf. Installed broader masks are documented rather than treated as live eligibility.
- 15 dungeon/class records: Blackfathom quests and Stormwind research referral, Warlock Orb of Soran'ruk (3small/1largefragments from differentdungeons) and three Shadowfang records. Class/faction-specific recipients remain separate; no complete dungeon or level coverage claimed.

Official UA_Forever 1.1.0 pinned at f34f1227d5837a05e18f1d5554d8aff6544b2515 with exact package/catalog hashes. Its quest catalog is unchanged from the previous batch pinned to1.1.0. All 50 new IDs and the composed catalog were counter-checked against it, current English and refreshed installed metadata.

All 236 available new source fields, including held proposals, have actual DeepL MY provenance, editorial review in seven connected 5–10 quest groups and separate independent assisted review. New held fields: 1. Unavailable current English stays null; quest97250progresshasUAonly and isnotconfirmedliveabsence. Uncertain fields preserve the original English fallback. The review report documents their reasons.

This extends connected early routes; it does not establish complete coverage of every race or level. All 310 currently saved states across132 quest IDs were covered before selection. Native Myanmar proofreading, new pronunciation approval and current live/controller testing remain pending.

Exit WoW fully, preserve SavedVariables, then replace the complete Myanmar_Forever_NorthshireTest folder in Interface/AddOns, keeping rebuilt font/catalog together.
