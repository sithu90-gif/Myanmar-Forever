# MyanmarForever 1.2.1

This update adds 12 quests across three early routes.

- **Silverpine Forest:** Lost Deathstalkers, Wild Hearts, Return to Quinn, Wild Eyes, Return to Quinn (Again), and Ivar the Foul. Wild Hearts follows the current English objective of three hearts.
- **Teldrassil:** The Lost Runner, Not Dead Yet, The Great Tree Provides, and Easing Suffering.
- **Durotar:** A Missing Hand and the first Threat from Below step connect to the two later steps already translated.

The Forever client data lists Ivar the Foul. Its live pickup condition still needs verification. Native Myanmar proofreading and live playtesting are pending.

Exit WoW before replacing the complete `Myanmar_Forever_NorthshireTest` folder in `Interface/AddOns`. Keep your SavedVariables to carry over settings and captures.
