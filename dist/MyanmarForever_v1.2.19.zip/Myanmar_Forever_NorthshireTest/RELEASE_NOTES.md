# MyanmarForever 1.2.19

Adds 50 quest records / 232 enabled translated fields. Total: 1,836 quest IDs / 8,381 enabled fields.

- **Class routes (20 records):** Horde Dogran/succubus steps, Alliance Heartswood/succubus steps, Forever incubus alternatives and Alliance Rogue referrals. Same-title summoning and exclusion branches stay distinct; eligibility is documented per ID.
- **Wetlands (15 records):** excavation and Ormer's Revenge, the cursed fleet and Eye of Paleth chain, archaeology, Dark Iron and Dragonmaw handoffs. Includes the Stockade dungeon handoff The Fury Runs Deep. Current minimum/recommended levels and installed metadata are recorded separately.
- **Hillsbrad and Ashenvale (15 records):** Elixir of Pain/Agony, Thistlefur/Foulweald, Stonetalon Standstill, Satyr Horns, Warsong supplies and the Befouled Element handoff. These expand the level 21–30 routes and class introductions; full race/level coverage is not implied.

Official UA_Forever 1.1.1 pinned at b0160a838849f8fc1e1c381e8669e3f4d8d5da6b with exact package/catalog hashes. Compared with the morning 1.1.0 pin, two UA Progress fields changed (111/8105); current English was refreshed and neither unsupported state was enabled. All 50 new IDs and the composed catalog were counter-checked against it, current English and refreshed installed metadata.

All 238 available new source fields, including held proposals, have actual DeepL MY provenance, editorial review in eight connected 5–10 quest groups and separate independent assisted review. New held fields: 6. Unavailable current English stays null; any UA-only state is recorded separately and never backtranslated. Uncertain fields preserve the original English fallback. The review report documents their reasons.

This extends connected early routes; it does not establish complete coverage of every race or level. All 310 currently saved states across 132 quest IDs were covered before selection. Native Myanmar proofreading, new pronunciation approval and current live/controller testing remain pending.

Exit WoW fully, preserve SavedVariables, then replace the complete Myanmar_Forever_NorthshireTest folder in Interface/AddOns, keeping rebuilt font/catalog together.
