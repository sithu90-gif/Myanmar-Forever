# MyanmarForever 1.1.1

- Adds six quests to finish the Westfall Toxic Soil storyline through Stormwind and the Deadmines. Both Explosive Consultation steps, both Detonation at a Distance steps and both Destruction in Deadmines steps have separate records.
- Corrects A Dynamite Plan to require **10 Rough Dynamite**, matching the live quest tracker.
- Includes the available offers, objectives, progress replies and turn-in text for these steps. The new wording has received assisted source review. Native proofreading and live testing are pending.

Exit WoW and replace the complete `Myanmar_Forever_NorthshireTest` folder in `Interface/AddOns`. Keep the existing SavedVariables so your settings and quest captures carry over.
