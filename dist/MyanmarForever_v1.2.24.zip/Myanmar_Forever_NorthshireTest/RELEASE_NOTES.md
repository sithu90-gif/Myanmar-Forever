# MyanmarForever 1.2.24

Adds 50 quest records / 221 enabled translated fields. Total: 2,086 quest IDs / 9,518 enabled fields.

- **Northern Eastern Kingdoms (20 records):** Wetlands/Thandol and Lost-item follow-ups, Alterac Syndicate, Hillsbrad/Tarren Mill/Dalaran, and both faction Turtle Bisques.
- **Desolace (19 records):** Alliance Relations, Khan/Bounty, the five Corrupter steps and six Vahlarriel search/rescue/vengeance records.
- **Early reward and Mage routes (11 records):** Alonso's three Dragonslayer turn-ins, plus the four-step Alliance and four-step Horde Mage garment routes.

Official UA_Forever 1.1.2 pinned at d7815c501035ad37c05f7a3b935724ae9b632fe5 with exact package/catalog hashes. The parsed quest records are unchanged from the preceding 1.1.2 pin. Earlier unsupported UA 111/8105 Progress states remain documented; no existing enabled translation needed correction. All 50 new IDs and the composed catalog were counter-checked against it, current English and refreshed installed metadata.

All 223 available new source fields, including held proposals, have actual DeepL MY provenance, editorial review in six connected 5–10 quest groups and separate independent assisted review. New held fields: 2. Unavailable current English stays null; any UA-only state is recorded separately and never backtranslated. Uncertain fields preserve the original English fallback. The review report documents their reasons.

This extends connected early routes; it does not establish complete coverage of every race or level. All 310 currently saved states across 132 quest IDs were covered before selection. Native Myanmar proofreading, new pronunciation approval and current live/controller testing remain pending.

Exit WoW fully, preserve SavedVariables, then replace the complete Myanmar_Forever_NorthshireTest folder in Interface/AddOns, keeping rebuilt font/catalog together.
