# MyanmarForever 1.2.3

This update continues after yesterday's completed 50-quest test. It adds 50 quest records and 227 enabled fields, bringing coverage to 1,086 quest IDs and 5,078 translated fields.

- Silverpine Forest: 8 followups, including Pyrewood Ambush, Wand to Bethor, the Hillsbrad handoff, A Husband's Revenge, Watching the Roads and the Forever Arugal/Stop the Spread steps.
- Druid class routes: 26 distinct bear, poison cure and aquatic chain records for the supported race/faction variants.
- Hunter class routes: 16 distinct taming/training steps for Tauren, Orc/Troll, Night Elf and Dwarf Hunters. Same-title quest IDs retain their own creature targets and trainers.

Current English supplies dialogue states absent from UA's catalog, including additional Silverpine replies and two documented secondary-English Druid progress references. Each state has source and review evidence.

Five dialogue fields remain disabled: four offers with unsupported gender alternatives (6064/6086 <lad/lass>, 6125/6130 <him/her>) and 6064.progress with conflicting male/gender-alternative English variants. Original English fallback and automatic capture remain available. Other unavailable English states remain absent. This release does not claim full all-race or all-class coverage through level 20.

Counter-checked against fresh official UA_Forever 0.26.0, exact commit 36a13111d8aa052675ce1125dc6a95c69a1526b6, and installed QuestieDB 1.0.12. Native Myanmar proofreading and current in-game/controller testing remain pending.

Fully exit WoW and replace the complete Myanmar_Forever_NorthshireTest folder in Interface/AddOns. Keep the bundled font and catalog together; preserve SavedVariables for settings and local captures.
