# MyanmarForever 1.2.14

Adds 50 quest records / 226 enabled translated fields. Total: 1,586 quest IDs / 7,244 enabled fields.

- 20 Ashenvale/Stonetalon records: the three hunt trophies and completion, Reclaiming the Charred Vale travel phase, Ziz Fizziks/Super Reaper/Gerenzo chain, Cenarius/Ordanus/Talon Den, Bloodfury, seed, elemental and Besseleth routes.
- 15 Wetlands records: Stonegear/ore, Greenwarden through Carnage, Gobbler and the statuette search, then Captain Stoutfist, Bolvar and Grayson handoffs.
- 15 Rogue class records: alternative Shattered Hand referrals, Ratchet treasure, Klaven and Zanzil stages, salute/deep-cover mission and Hinott's cure. Individual faction/class restrictions apply.

Official UA_Forever 1.0.5 pinned at 0c0b63b09b993ae8a17743c34f24ee02e9e6b65b with exact package/catalog hashes. Its quest catalog is byte-for-byte identical to 1.0.4. All 50 new IDs and the composed catalog were counter-checked against it, current English and refreshed installed metadata.

All 231 available new source fields, including held proposals, have actual DeepL MY provenance, editorial review in seven connected 5–10 quest groups and separate independent assisted review. New held fields: 5. Genuine source absences stay null; uncertain fields preserve the original English fallback. The review report documents their reasons.

This extends connected early routes; it does not establish complete coverage of every race or level. All 300 previously saved states across 128 quest IDs were covered before selection. Native Myanmar proofreading, new pronunciation approval and current live/controller testing remain pending.

Exit WoW fully, preserve SavedVariables, then replace the complete Myanmar_Forever_NorthshireTest folder in Interface/AddOns, keeping rebuilt font/catalog together.
