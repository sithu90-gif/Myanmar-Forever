# MyanmarForever 1.2.23

Adds 50 quest records / 227 enabled translated fields. Total: 2,036 quest IDs / 9,297 enabled fields.

- **Kalimdor (20 records):** Ashenvale dryad/Satyr and orc follow-ups; Freewind/Highperch/Swarm and Shimmering Flats tasks; To the Top and Fish in a Bucket service/repeatable interactions.
- **Alliance (20 records):** Bloom of the Heavens recovery before the already-covered delivery, Loch Modan forge and Wetlands Spark of Freedom, plus all17 distinct Missing Diplomat steps.
- **Warlock (10 records):** three Seeking Strahad referrals, both Tome of the Cabal paths and their shared final Binding, counted once per ID.

Official UA_Forever 1.1.2 pinned at d7815c501035ad37c05f7a3b935724ae9b632fe5 with exact package/catalog hashes. The parsed quest records are unchanged from the preceding 1.1.2 pin. Earlier unsupported UA 111/8105 Progress states remain documented; no existing enabled translation needed correction. All 50 new IDs and the composed catalog were counter-checked against it, current English and refreshed installed metadata.

All 228 available new source fields, including held proposals, have actual DeepL MY provenance, editorial review in six connected 5–10 quest groups and separate independent assisted review. New held fields: 1. Unavailable current English stays null; any UA-only state is recorded separately and never backtranslated. Uncertain fields preserve the original English fallback. The review report documents their reasons.

This extends connected early routes; it does not establish complete coverage of every race or level. All 310 currently saved states across 132 quest IDs were covered before selection. Native Myanmar proofreading, new pronunciation approval and current live/controller testing remain pending.

Exit WoW fully, preserve SavedVariables, then replace the complete Myanmar_Forever_NorthshireTest folder in Interface/AddOns, keeping rebuilt font/catalog together.
