# MyanmarForever 1.2.5

This morning's update adds 50 Paladin, Rogue and Warlock quest records with 205 translated fields. It also restores 49 supported replies in 31 existing quests and applies 68 guarded corrections to older fields. Total coverage: 1,186 quest IDs and 5,547 translated fields.

- Paladin: 24 Human/Dwarf Tome of Divinity, Symbol of Life and trainer-introduction records.
- Rogue: 16 Shattered Hand, SI:7, Onin, Erion, Redridge lockbox and Undead training records.
- Warlock: 10 early familiar and separate Horde/Alliance Voidwalker chains.
- Existing routes: restored Undead Light-training, mainland starter/profession, Night Elf follow-up and Skyborne faction-arrival replies.

The fresh UA_Forever 0.26.5 release was checked by exact commit 1fee3ca08cfcafb2314785ef4386be87f618e7ef, package and catalog SHA-256. Its 472 new dialogue states affect 303 existing Myanmar quest IDs. All 1,515 contextual field slots were compared against current English or preserved prior evidence. Current source changes include 8 Defias Rogue Wizards, 7 + 4 Murloc targets, 6 blood vials + 18 Duskweed petals, an east direction, Bandarion Keep and dynamic class markers.

Two Skyborne arrival replies are now supported by fresh installed race masks, prerequisites, offers and the current primary/upstream states. The old historical hold is retained as resolved evidence and removed from the active-hold report. This does not claim live verification.

Seven fields in the new records and six supported fields in the refreshed existing records remain disabled for unresolved branches, legacy offers or placeholder text. 109 other audited missing states have no available English; seven previously reviewed enabled states lack a fresh current English state and retain prior evidence with an explicit review limitation. Older holds remain recorded.

All new translations and current correction sources have raw DeepL MY evidence, separate English/Myanmar editorial review and independent assisted review. Names, targets, quantities, directions, stage instructions and exact player markers were checked. The Stormfist pronunciation is reconciled consistently under prior-text hash guards. Native Myanmar proofreading, pronunciation approval and current in-game/controller testing remain pending.

Fully exit WoW, preserve SavedVariables, and replace the complete Myanmar_Forever_NorthshireTest folder in Interface/AddOns. Keep the rebuilt font and catalog together. Automatic local missing-dialogue capture remains enabled; reload or logout saves captures. No CurseForge or social publication is part of this release.
