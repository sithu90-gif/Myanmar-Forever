# MyanmarForever 1.2.6

The conditional afternoon update adds 50 quest records and 220 translated fields, restores three supported Progress replies and applies two guarded corrections to older fields. Total coverage: 1,236 quest IDs and 5,770 translated fields. Today's morning and afternoon batches total 100 new records.

- Priest: 20 early garments, Gnome memorandum, Night Elf homecoming/Stars and Troll Hex records, with distinct race/trainer steps.
- Alliance: 15 Ashenvale records covering the first Raene steps, Zoram/Talen, Bathran/Pelturas and elemental-bracer/Sarilus routes.
- Horde: 15 Stonetalon, Thunder Bluff and Tarren Mill records covering the toxin chain, Kaya escort/report, Grimtotem, Resonite and spider tasks.

Fresh official UA_Forever 1.0.0 was pinned to exact commit 3487d77e9ec21795d31f63ba3941c31efbe4403d, package and catalog SHA-256. All selected IDs and fields were compared. The upstream corrects quest 490's formerly obsolete label to the English-supported text we already ship; no generic UNUSED runtime alias was added.

The existing-source audit checked 315 fields across 61 affected IDs and two availability rechecks. Three newly English-supported replies are added for Nip 'Em in the Bud, Secure the Mountain and Rime's Wrath. Current class-marker case and the full Dark Iron spies identity are corrected under prior-text hash guards. The existing class-specific Sparring Match offer remains held; its current English is available but applicability to Warriors remains unverified. The captured Camping 101: Herbalism reply remains preserved with its prior reviewed evidence.

Five new Priest fields remain disabled for unsupported gender branches or conflicting legacy steps. Genuine absent states remain explicit. The supported secondary Progress for An Aggressive Defense and completion for Returning Home are included with field-specific evidence. The Foulweald objective retains all current-English targets, including two Ursas omitted by UA. The Apothecary Zamah rank spelling is reconciled within the new chain as an assisted consistency proposal.

All available new fields and existing-state proposals have raw DeepL MY evidence, separate English/Myanmar review and independent assisted review. Native Myanmar proofreading, pronunciation approval and current in-game/controller verification remain pending. Selected route coverage does not establish complete race/level coverage.

Fully exit WoW, preserve SavedVariables and replace the complete Myanmar_Forever_NorthshireTest folder in Interface/AddOns. Keep the rebuilt font and catalog together. Automatic local missing-dialogue capture remains enabled; reload or logout saves captures. This release is not published to CurseForge or social media.
