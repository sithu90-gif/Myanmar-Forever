# MyanmarForever 1.2.9

This morning update adds 50 quest records and 209 translated fields. Total: 1,336 quest IDs and 6,140 enabled fields.

- Druid 20: remaining Night Elf/Tauren training referrals, four Skyborne/Nighthaven introductions, and both faction Cat Spirit routes through relics, blessings and return-to-trainer steps.
- Shaman 20: six early Earth/Fire/referral/recovery records and fourteen Horde Water Totem records, including the full waterskin/cleansing/spirit/return chain and recovery.
- Alliance Shaman 10: the complete current Water Totem route and Water Sapta recovery through Loch Modan, Wetlands, Redridge, Ashenvale and Westfall.

Cat middle steps remain Night Elf/Tauren-restricted in metadata despite broader Skyborne entry/final masks; live Skyborne continuity is unverified. The Water unlock requires level 20; connected quest levels extend through 23. These are selected class routes, not a claim of complete coverage or live eligibility for every race. Same-title alternatives remain distinct by ID, faction, recipient and stage.

Official UA_Forever 1.0.1 was freshly pinned to exact commit ab388ca8df990310d96320c88689831587f76e33 and package/catalog SHA-256. Its sole changed quest label 140 now matches our already reviewed Captain Sander's Hidden Treasure title. All available current English fields and all 50 planned IDs were compared. Older reviewed text is preserved, including the 1.2.8 hold on 5639.detail.

Current English controls meaning. Waterskin colors, locations, recipients, reagent items and ritual instructions are retained. Unavailable states and conflicting legacy/source variants remain explicit; 5 new fields are held rather than guessed. Source-specific differences from UA and installed metadata are recorded in the review evidence. No unsupported gender substitution or hardcoded player-name replacement was invented.

Every available new field or held proposal has raw DeepL MY evidence and English/input/output/final hashes, followed by editorial review, separate group rereads and independent assisted review. Maintained local pronunciations were used; DeepL cloud glossary access still requires Pro. Native Myanmar proofreading, new pronunciation approval and current in-game/controller testing remain pending.

Fully exit WoW, preserve SavedVariables and replace the complete Myanmar_Forever_NorthshireTest folder in Interface/AddOns. Keep rebuilt font/catalog together. Automatic local missing-state capture remains enabled; reload or logout saves captures. No CurseForge or social publishing is included.
