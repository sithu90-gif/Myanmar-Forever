# MyanmarForever 1.2.16

Adds 50 quest records / 241 enabled translated fields. Total: 1,686 quest IDs / 7,718 enabled fields.

- 20 Barrens records: Mangletooth/Blood Shards/Betrayal, Gann reclamation and revenge, Mahren/Isha Awak, rare-beast turn-ins, Chen's final recipe, weapon collection, Nightmare Shard faction handoffs and paired Chol'aruk bounties.
- 15 Wetlands/Loch Modan records: Chok'sul, Rockgar/Algaz/Stoutfist, crocolisk/scales/crate/incisor chain, spoils, alchemy and Menethil deliveries. Quest473 requires23 and98245 requires21;98072 minimum19 is current-primary evidence because installed minimum is absent.
- 15 Hillsbrad records: all seven Battle of Hillsbrad stages, Scout Support/Valuable Vantages, Elixir of Suffering collection/application, The Rescue, Souvenirs of Death and Syndicate bounty.550 is a level32/minimum19 capital commendation. Later rescue and Syndicate continuations533/566 remain outside this batch.

Official UA_Forever 1.1.0 pinned at f34f1227d5837a05e18f1d5554d8aff6544b2515 with exact package/catalog hashes. Its quest catalog is unchanged from the previous batch pinned to1.1.0. All 50 new IDs and the composed catalog were counter-checked against it, current English and refreshed installed metadata.

All 246 available new source fields, including held proposals, have actual DeepL MY provenance, editorial review in seven connected 5–10 quest groups and separate independent assisted review. New held fields: 5. Genuine source absences stay null; uncertain fields preserve the original English fallback. The review report documents their reasons.

This extends connected early routes; it does not establish complete coverage of every race or level. All 300 previously saved states across 128 quest IDs were covered before selection. Native Myanmar proofreading, new pronunciation approval and current live/controller testing remain pending.

Exit WoW fully, preserve SavedVariables, then replace the complete Myanmar_Forever_NorthshireTest folder in Interface/AddOns, keeping rebuilt font/catalog together.
