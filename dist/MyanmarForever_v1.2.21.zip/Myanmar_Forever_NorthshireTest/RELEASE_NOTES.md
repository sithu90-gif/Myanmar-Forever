# MyanmarForever 1.2.21

Adds 50 quest records / 234 enabled translated fields. Total: 1,936 quest IDs / 8,839 enabled fields.

- **Class routes (11 records):** five remaining level20 Warlock handoffs and six connected Althalaxx Orb Paladin quests. Same-title handoffs retain separate quest IDs.
- **Dungeon routes (19 records):** Gnomeregan trainer handoffs, collection and faction travel chains, plus four Stockade sidequests. Machine timing, unstable fallout and escort conditions are checked per field.
- **Regional routes (20 records):** Gloomrise/Skywatcher Plateau in Mulgore, Thousand Needles escorts and follow-ups, plus Hillsbrad, Ashenvale, Blackfathom and Barrens handoffs. Sixteen are current Horde records; the two pelts and two Hillsbrad handoffs are current Alliance records. Installed and current eligibility remain separate; live pickup remains untested.

Official UA_Forever 1.1.2 pinned at d7815c501035ad37c05f7a3b935724ae9b632fe5 with exact package/catalog hashes. Parsed quest records are unchanged from the preceding 1.1.1 pin; exact catalog bytes are separately hashed. Earlier unsupported UA 111/8105 Progress states remain documented; six older pronunciation fields were reconciled under exact prior hashes. All 50 new IDs and the composed catalog were counter-checked against it, current English and refreshed installed metadata.

All 235 available new source fields, including held proposals, have actual DeepL MY provenance, editorial review in seven connected 5–10 quest groups and separate independent assisted review. New held fields: 1. Unavailable current English stays null; any UA-only state is recorded separately and never backtranslated. Uncertain fields preserve the original English fallback. The review report documents their reasons.

This extends connected early routes; it does not establish complete coverage of every race or level. All 310 currently saved states across 132 quest IDs were covered before selection. Native Myanmar proofreading, new pronunciation approval and current live/controller testing remain pending.

Exit WoW fully, preserve SavedVariables, then replace the complete Myanmar_Forever_NorthshireTest folder in Interface/AddOns, keeping rebuilt font/catalog together.
