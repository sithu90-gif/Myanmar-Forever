# MyanmarForever 1.2.4

The conditional afternoon update adds 50 supported class-route quest records and 215 enabled fields after this morning's 1.2.3 release. Total coverage is 1,136 quest IDs and 5,293 translated fields. Today reaches the 100-new-record ceiling.

- Warrior: 20 early Horde, Human, Dwarf and Night Elf route records through training and weapon followups.
- Mage: 14 early training, sample/gizmo and separate Alliance/Horde robe chains, including two reward-only turn-ins.
- Shaman: 16 records across distinct Horde/Alliance Earth rites, the Horde Fire rite and Earth Sapta replacements.

The source fetcher now excludes the website's provided-item widget from quest objectives. Source inspection confirmed this affected three current Shaman pages and neither completed earlier batch.

New disabled fields: 4. Conflicting Warrior gender-address completions and unverified legacy Sapta offers remain on hold with source evidence. Other English-unavailable states retain fallback; prior holds remain preserved. These selected level 4-16 records do not establish complete all-race/all-class coverage.

Fresh official UA_Forever 0.26.0, exact commit 36a13111d8aa052675ce1125dc6a95c69a1526b6, and installed QuestieDB 1.0.12 were checked. Native Myanmar proofreading and current in-game/controller testing are pending.

Fully exit WoW, preserve SavedVariables, and replace the complete Myanmar_Forever_NorthshireTest folder in Interface/AddOns. Keep the rebuilt font and catalog together.
