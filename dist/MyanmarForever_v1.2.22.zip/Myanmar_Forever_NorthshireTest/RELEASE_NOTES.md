# MyanmarForever 1.2.22

Adds 50 quest records / 231 enabled translated fields. Total: 1,986 quest IDs / 9,070 enabled fields.

- **Treasure and Kalimdor routes (13 records):** the connected five-step note/treasure trail, Ashenvale/Forest Song and Stonetalon/Barrens follow-ups. Item-started and faction restrictions are recorded per ID.
- **Wetlands routes (20 records):** Excavation Sites stories, Grassman/Songblade and Titan Relic handoffs, Whelgar's knowledge sequence and the three Noble Brew steps. This geographic group includes both faction paths.
- **Southshore, tribute and dungeon routes (17 records):** Farren's coastal investigation and Stormwind report, the full Sully/Sara/royal tribute chain, and Razorfen/Blackfathom sidequests with separate faction Pearl turn-ins.

Official UA_Forever 1.1.2 pinned at d7815c501035ad37c05f7a3b935724ae9b632fe5 with exact package/catalog hashes. The parsed quest records are unchanged from the preceding 1.1.2 pin. Earlier unsupported UA 111/8105 Progress states remain documented; no existing enabled translation needed correction. All 50 new IDs and the composed catalog were counter-checked against it, current English and refreshed installed metadata.

All 231 available new source fields, including held proposals, have actual DeepL MY provenance, editorial review in seven connected 5–10 quest groups and separate independent assisted review. New held fields: 0. Unavailable current English stays null; any UA-only state is recorded separately and never backtranslated. Uncertain fields preserve the original English fallback. The review report documents their reasons.

This extends connected early routes; it does not establish complete coverage of every race or level. All 310 currently saved states across 132 quest IDs were covered before selection. Native Myanmar proofreading, new pronunciation approval and current live/controller testing remain pending.

Exit WoW fully, preserve SavedVariables, then replace the complete Myanmar_Forever_NorthshireTest folder in Interface/AddOns, keeping rebuilt font/catalog together.
