# MyanmarForever 1.2.25

Adds 50 quest records / 233 enabled translated fields. Total: 2,136 quest IDs / 9,751 enabled fields.

- **Class routes (20 records):** six Rogue Ravenholdt follow-ups, seven Mage wand/marsh steps and seven Warrior Islander/Affray/Whirlwind records.
- **Stranglethorn routes (20 records):** Nesingwary handoff/camp, every Tiger/Panther/Raptor Mastery step, Big Game Hunter and all four Green Hills chapters/book. Connected endpoints reach quest level43 with required28.
- **Alliance Desolace (10 records):** Reclaimers introduction, four Karnitol Shipwreck steps, four Reagents steps and Centaur Bounty.

Official UA_Forever 1.1.2 pinned at d7815c501035ad37c05f7a3b935724ae9b632fe5 with exact package/catalog hashes. The parsed quest records are unchanged from the preceding 1.1.2 pin. Earlier unsupported UA 111/8105 Progress states remain documented; no existing enabled translation needed correction. All 50 new IDs and the composed catalog were counter-checked against it, current English and refreshed installed metadata.

All 234 available new source fields, including held proposals, have actual DeepL MY provenance, editorial review in six connected 5–10 quest groups and separate independent assisted review. New held fields: 1. Unavailable current English stays null; any UA-only state is recorded separately and never backtranslated. Uncertain fields preserve the original English fallback. The review report documents their reasons.

This extends connected early routes; it does not establish complete coverage of every race or level. All 310 currently saved states across 132 quest IDs were covered before selection. Native Myanmar proofreading, new pronunciation approval and current live/controller testing remain pending.

Exit WoW fully, preserve SavedVariables, then replace the complete Myanmar_Forever_NorthshireTest folder in Interface/AddOns, keeping rebuilt font/catalog together.
