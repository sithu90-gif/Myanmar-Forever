# MyanmarForever 1.2.11

Adds 50 camping quest records and 230 translated fields. Total: 1,436 quest IDs / 6,594 enabled fields.

- Kharanos/Ironforge: 14 selected camping introduction, rest, cooking and profession records.
- Dolanaar/Darnassus/Darkshore: 14 records, including remote Auberdine trainers.
- Bloodhoof/Thunder Bluff: 14 records, including the Venture Co. Mine engineer.
- Razor Hill/Orgrimmar: eight records covering the introduction, rest, cooking and five profession referrals; six more profession branches remain.

Selected metadata has required level 4 and quest level 6. Profession skill metadata, visible UI requirements and recipe conditions remain distinct; no numeric threshold or live race eligibility was invented. Same-title IDs retain their own instructors, journal/supply objectives, campfire and Boosted Rest conditions, destinations and current marker case.

Fresh official UA_Forever 1.0.1 exact commit ab388ca8df990310d96320c88689831587f76e33 and package/catalog hashes were checked against the composed catalog and all 50 planned IDs. The catalog is unchanged from 1.2.10. Current English controls meaning. Absent Progress is not filled from UA alone; current Faction Banner/Rallying Banner field differences remain documented.

All available English fields and held proposals have actual DeepL MY provenance, editorial correction, separate connected-group reviews and fresh independent review. Maintained local phonetics were applied; cloud glossaries require Pro. New held fields: 0. Historical text and all prior holds are preserved. Native Myanmar proofreading, new pronunciation approval and current in-game/controller testing remain pending.

Exit WoW fully, preserve SavedVariables and replace the complete Myanmar_Forever_NorthshireTest folder in Interface/AddOns, keeping rebuilt font/catalog together. Automatic local missing-state capture remains enabled; reload or logout saves captures. No CurseForge or social publishing.
