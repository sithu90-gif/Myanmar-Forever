# MyanmarForever 1.2.8

This afternoon repair disables one unsupported translated offer for Desperate Prayer, quest 5639. It adds no quest records or translated fields. Total coverage is 1,286 quest IDs and 5,931 enabled fields.

The current Forever primary page is completion-only and explicitly marks its description and objective as removed. The secondary source still carries an older referral to Laurena in Stormwind. The earlier 1.2.7 release enabled that secondary offer using installed/UA relations; this repair withdraws that overconfident fallback. The removal marker was already present in the morning source, not newly introduced upstream.

The quest's reviewed title and completion remain available. An absent/held offer retains original-language fallback and automatic local capture. Every other quest field is preserved byte-for-byte in the composed source; the original 1.2.7 source and raw translation evidence remain unchanged.

The builder now permits a disabled existing field only with a documented hold and its exact prior translation hash. Missing/wrong prior hashes, undocumented removal, an already absent field and empty-string bypasses are rejected. Independent source/code reviews and Python/Lua/catalog/font/ZIP checks accompany the package.

Official UA_Forever 1.0.0 and installed QuestieDB 1.0.12 were freshly checked. Existing trainer/city, spell-identity, literal-name and gender-handling holds remain explicit. Native Myanmar proofreading, pronunciation approval and current in-game/controller verification remain pending.

The conditional extra 50 quests were skipped because this follow-up was used to repair and validate an enabled-source issue. Today's new-record count remains 50 from the morning batch. No CurseForge or social publishing is included.

Fully exit WoW, preserve SavedVariables and replace the complete Myanmar_Forever_NorthshireTest folder in Interface/AddOns. Keep the rebuilt font and catalog together. Reload or logout saves automatic captures.
