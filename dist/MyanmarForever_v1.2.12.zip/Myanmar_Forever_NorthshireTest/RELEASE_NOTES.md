# MyanmarForever 1.2.12

Adds 50 early-route quest records and 237 translated fields. Total: 1,486 quest IDs / 6,831 enabled fields.

- Twelve remaining Human and Razor Hill camping profession referrals.
- Twenty Alliance craft/cooking/fishing, Deeprun, early Dun Morogh and Stormwind library records. The library chain 343->344->345->347->346 stays connected; 97914 leads to already translated 97926.
- Eighteen Undercity/Silverpine and shared Wailing Caverns/Ratchet records, including samples, timed potion delivery, Offering Stone phases and dungeon collections.

Selected installed quest levels span 2-24 with per-ID race/class/profession restrictions; shared neutral quests count once. This does not establish complete race/level coverage or current live eligibility. Quantity/item bindings, recipients, directions, time conditions and current marker case are preserved.

Official UA_Forever 1.0.2 was freshly pinned to exact commit 6c4d08cdf1539e1d79d181e8acf6115fd45f8a73, package and catalog SHA-256. Its five English-label corrections 275/306/634/684/685 match current English, change no UA dialogue and affect no existing or newly selected translation. All 50 planned IDs were counter-checked. Current English controls meaning; source absences, recipe/link differences and field-specific labels remain documented.

All available English fields and held proposals have actual DeepL MY provenance, editorial correction, separate 5-10-quest bilingual rereads and fresh independent source-aware review. Local maintained terms were used; the new Kaldorei/kaldorei case alias follows the capitalized maintained spelling while historical variants stay unchanged. Cloud glossaries require Pro. New held fields: 0. Native Myanmar proofreading, new pronunciation approval and current in-game/controller testing remain pending.

Exit WoW fully, preserve SavedVariables and replace the complete Myanmar_Forever_NorthshireTest folder in Interface/AddOns, keeping rebuilt font/catalog together. Automatic local missing-state capture remains enabled; reload or logout saves captures. No CurseForge or social publishing.
