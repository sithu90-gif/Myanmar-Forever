# MyanmarForever 1.2.20

Adds 50 quest records / 224 enabled translated fields. Total: 1,886 quest IDs / 8,605 enabled fields.

- **Early/helper and class routes (12 records):** Stormwind Library and two Onu helper states; four Duskwood spirit tasks; Ravenholdt and Forever Rogue steps. Partial helper/reward states, copied instructions, placeholder text and current class/race restrictions are documented per ID.
- **Thousand Needles (18 records):** Faith, Endurance, Strength and the full Lore/Final Passage sequence; Freewind/Grimtotem, Alien Egg, Sacred Fire, Arikara and Wind Rider routes. Two connected Lore steps are recommended level36 and currently require26; broader source ranges are explicit.
- **Ashenvale and Wetlands (20 records):** the Scythe of Elune travel/investigation sequence and Kayneth handoff; Dragonmaw/Nek'rosh classic and Forever follow-ups, plus the Bloom of the Heavens return. These extend connected routes; complete race/level or live eligibility coverage is not implied.

Official UA_Forever 1.1.1 pinned at b0160a838849f8fc1e1c381e8669e3f4d8d5da6b with exact package/catalog hashes. The actual quest catalog is unchanged from the preceding 1.1.1 pin. Earlier unsupported UA 111/8105 Progress states remain documented; no existing enabled translation needed correction. All 50 new IDs and the composed catalog were counter-checked against it, current English and refreshed installed metadata.

All 230 available new source fields, including held proposals, have actual DeepL MY provenance, editorial review in six connected 5–10 quest groups and separate independent assisted review. New held fields: 6. Unavailable current English stays null; any UA-only state is recorded separately and never backtranslated. Uncertain fields preserve the original English fallback. The review report documents their reasons.

This extends connected early routes; it does not establish complete coverage of every race or level. All 310 currently saved states across 132 quest IDs were covered before selection. Native Myanmar proofreading, new pronunciation approval and current live/controller testing remain pending.

Exit WoW fully, preserve SavedVariables, then replace the complete Myanmar_Forever_NorthshireTest folder in Interface/AddOns, keeping rebuilt font/catalog together.
