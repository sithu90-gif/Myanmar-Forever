# MyanmarForever 1.2.2

This update adds 50 supported early-route quest records and a missing progress reply for A Rogue's Deal (590).

- **Silverpine Forest — 25 quests:** the Dead Fields/Rot Hide and Dalaran investigation chains, three separate A Recipe for Death steps, the Sepulcher–Undercity flight introduction, Erland's escort, the engraved ring and Alaric's first two steps.
- **Durotar and the Barrens — 12 quests:** southern road and Echo Isles errands, Razor Hill follow-ups and the Dry Hills tanner storyline.
- **Teldrassil, Darkshore and Elwynn — 13 quests:** two distinct Crown of the Earth delivery steps, additional early quests and optional/repeatable Applejack interactions. Unavailable offer/objective fields remain absent for the repeatable interactions.

The catalog contains 1,036 quest IDs and 4,851 translated fields. These additions reach quest levels 1–18 across the selected routes; they do not establish complete coverage of every race through level 20.

The batch was counter-checked against freshly pinned UA_Forever 0.26.0 and installed QuestieDB 1.0.12. Current English supports quest 490 as Bounty: Gnarlpine Furbolg despite UA's obsolete `<UNUSED>` label; the addon retains the current title guard. An English-unavailable progress candidate for Secure the Mountain (98322) remains disabled. Native Myanmar proofreading and current in-game/controller testing remain pending.

Fully exit WoW, back up your addon and SavedVariables, then replace the complete `Myanmar_Forever_NorthshireTest` folder in `Interface/AddOns`. Keep the bundled font and catalog together. Existing settings and automatic local quest capture are preserved.
