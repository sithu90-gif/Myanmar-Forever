# MyanmarForever 1.2.18

Adds 50 quest records / 196 enabled translated fields. Total: 1,786 quest IDs / 8,149 enabled fields.

- **Alliance Warrior (14 records):** Yorus, the Rethban Gauntlet, Shieldsmith and Fire Hardened Mail, followed by the Human Grimand, Night Elf Mathiel and Dwarf/Gnome Klockmort armor branches. Minimum entry level 20; quest levels 20–30.
- **Horde Warrior (14 records):** Ruga's trial, Thun'grim's Brutal Armor, then the Satyr Hooves, Chimaeric Horn and Dragonmaw Shinbones branches and armor rewards.
- **Paladin and early routes (22 records):** ten Human/Dwarf Valor and Righteousness records; Troll Warlock introduction; two Sapta helpers; Engineering camp tutorial; three Skyborne Druid feline-form steps; Goddess Provides, Alther's Mill, An Ancient Grudge and two pet quests. Current restrictions and unverified helper activation are documented per ID.

Official UA_Forever 1.1.0 pinned at f34f1227d5837a05e18f1d5554d8aff6544b2515 with exact package/catalog hashes. Its quest catalog is unchanged from the previous batch pinned to 1.1.0. All 50 new IDs and the composed catalog were counter-checked against it, current English and refreshed installed metadata.

All 200 available new source fields, including held proposals, have actual DeepL MY provenance, editorial review in seven connected 5–10 quest groups and separate independent assisted review. New held fields: 4. Unavailable current English stays null; any UA-only state is recorded separately and never backtranslated. Uncertain fields preserve the original English fallback. The review report documents their reasons.

This extends connected early routes; it does not establish complete coverage of every race or level. All 310 currently saved states across 132 quest IDs were covered before selection. Native Myanmar proofreading, new pronunciation approval and current live/controller testing remain pending.

Exit WoW fully, preserve SavedVariables, then replace the complete Myanmar_Forever_NorthshireTest folder in Interface/AddOns, keeping rebuilt font/catalog together.
